CS3551 – DISTRIBUTED COMPUTING
Project: Distributed Process Communication Simulator

FILES
1. Distributed_Process_Communication_Assignment.docx – assignment report
2. distributed_process_simulator.py – Python implementation

REQUIREMENTS
- Python 3.8 or later
- No third-party packages are required

HOW TO RUN
1. Extract this ZIP file.
2. Open the extracted folder in VS Code or a terminal.
3. Run:
   python distributed_process_simulator.py

On Windows, run the command from a terminal (PowerShell or Command Prompt).
The program uses Python's multiprocessing and Queue modules.

PROJECT OVERVIEW
Process 1 is the sender. Processes 2, 3 and 4 are receivers.
The sender places a message in each receiver's FIFO queue. A None
value is sent as a stop signal after the message. Each receiver reads
its message and reports completion.

NOTE
The order of receiver log lines may vary because the processes execute
concurrently. The message delivered to each receiver remains the same.
