from multiprocessing import Process, Queue
from queue import Empty
import time


def sender(receiver_queues, log_queue):
    """Send one message to each receiver process."""
    message = "Hello from Process 1"
    for process_id, message_queue in receiver_queues.items():
        message_queue.put(message)
        log_queue.put(f"Process 1: Sent message to Process {process_id}")

    # A None value tells each receiver that no more messages are coming.
    for message_queue in receiver_queues.values():
        message_queue.put(None)


def receiver(process_id, message_queue, log_queue):
    """Receive messages until the stop signal (None) is received."""
    while True:
        message = message_queue.get()
        if message is None:
            log_queue.put(f"Process {process_id}: Communication completed")
            break

        log_queue.put(f"Process {process_id}: Received message: {message}")


def main():
    log_queue = Queue()

    # Separate FIFO queue for each receiver.
    receiver_queues = {
        2: Queue(),
        3: Queue(),
        4: Queue()
    }

    # Start receiver processes first so they are ready to receive messages.
    receiver_processes = []
    for process_id, message_queue in receiver_queues.items():
        process = Process(
            target=receiver,
            args=(process_id, message_queue, log_queue)
        )
        process.start()
        receiver_processes.append(process)

    # Start the sender process.
    sender_process = Process(
        target=sender,
        args=(receiver_queues, log_queue)
    )
    sender_process.start()

    sender_process.join()
    for process in receiver_processes:
        process.join()

    # Print collected logs from the main process.
    print("DISTRIBUTED PROCESS COMMUNICATION SIMULATOR")
    print("-------------------------------------------")
    while True:
        try:
            print(log_queue.get_nowait())
        except Empty:
            break
    print("-------------------------------------------")
    print("Message passing completed successfully.")


if __name__ == "__main__":
    main()
